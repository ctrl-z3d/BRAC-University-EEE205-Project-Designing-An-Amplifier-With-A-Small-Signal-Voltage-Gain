*version 9.2 2928958841
u 166
C? 4
Q? 2
PM? 2
? 2
R? 3
@libraries
@analysis
.TRAN 1 0 0 0
+0 0ns
+1 200ms
+2 196ms
+3 0.01ms
.STEP 0 0 4
+ 0 RL
+ 4 1k
+ 5 10k
+ 6 0.5k
.OP 0 
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 5328 
@status
n 0 126:00:06:03:32:25;1767648745 e 
s 2832 126:00:06:03:32:29;1767648749 e 
*page 1 0 1520 970 iB
@ports
port 17 GND_EARTH 610 140 h
port 18 GND_EARTH 500 440 h
@parts
part 5 VDC 500 110 v
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vcc
a 1 xp 9 0 26 23 hcn 100 REFDES=Vcc
a 0 sp 0 0 22 37 hln 100 PART=VDC
a 1 u 13 0 -11 24 hcn 100 DC=10v
part 12 c 340 250 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 11 0 hln 100 REFDES=C2
a 0 u 13 0 5 31 hln 100 VALUE=1uF
part 9 c 620 240 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
a 0 u 13 0 15 25 hln 100 VALUE=1uF
part 11 R 560 210 v
a 0 sp 0 0 0 10 hlb 100 PART=R
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R_C
a 0 xp 9 0 15 0 hln 100 REFDES=R_C
a 0 u 13 0 17 37 hln 100 VALUE=12k
part 13 vsin 280 300 h
a 1 u 0 0 0 0 hcn 100 AC=0
a 1 u 13 13 48 10 hcn 100 VOFF=0
a 0 x 0:13 0 0 0 hln 100 PKGREF=Vi
a 1 xp 9 0 -8 22 hcn 100 REFDES=Vi
a 1 u 13 13 52 24 hcn 100 VAMPL=10mv
a 1 u 13 13 50 38 hcn 100 FREQ=1k
part 15 r 720 300 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=RL
a 0 xp 9 0 15 0 hln 100 REFDES=RL
a 0 u 13 0 15 31 hln 100 VALUE=10k
part 6 R 430 210 v
a 0 x 0:13 0 0 0 hln 100 PKGREF=R1
a 0 xp 9 0 15 0 hln 100 REFDES=R1
a 0 sp 0 0 0 10 hlb 100 PART=R
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 15 37 hln 100 VALUE=330k
part 8 R 430 340 v
a 0 x 0:13 0 0 0 hln 100 PKGREF=R2
a 0 xp 9 0 15 0 hln 100 REFDES=R2
a 0 sp 0 0 0 10 hlb 100 PART=R
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 u 13 0 17 31 hln 100 VALUE=68k
part 92 c 600 400 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=C_E
a 0 xp 9 0 15 0 hln 100 REFDES=C_E
a 0 u 13 0 11 41 hln 100 VALUE=2.2u
part 7 R 560 410 v
a 0 sp 0 0 0 10 hlb 100 PART=R
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 x 0:13 0 0 0 hln 100 PKGREF=R_E
a 0 xp 9 0 15 0 hln 100 REFDES=R_E
a 0 u 13 0 5 -3 hln 100 VALUE=2.2k
part 14 BD135/PLP 540 260 h
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-126
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 ap 9 0 1 6 hln 100 REFDES=Q1
a 0 sp 11 0 22 22 hln 100 PART=BD135/PLP
a 0 a 0:13 0 0 0 hln 100 PKGREF=Q1
part 1 titleblk 1520 970 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=B
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 300 95 hrn 100 PAGENO=1
part 19 nodeMarker 720 240 h
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 s 0 0 0 0 hln 100 PROBEVAR=
a 0 a 0 0 4 22 hlb 100 LABEL=22
@conn
w 22
a 0 up 0:33 0 0 0 hln 100 V=
s 540 110 610 110 21
a 0 up 33 0 575 109 hct 100 V=
s 610 110 610 140 23
w 26
a 0 up 0:33 0 0 0 hln 100 V=
s 430 300 430 260 25
s 430 260 540 260 29
a 0 up 33 0 485 259 hct 100 V=
s 430 210 430 250 31
s 430 250 430 260 35
s 370 250 430 250 33
w 45
a 0 up 0:33 0 0 0 hln 100 V=
s 430 110 500 110 44
s 430 160 430 110 46
s 560 160 430 160 48
a 0 up 33 0 495 159 hct 100 V=
s 560 170 560 160 50
s 430 170 430 160 52
w 55
a 0 up 0:33 0 0 0 hln 100 V=
s 560 240 560 210 54
s 560 240 620 240 56
a 0 up 33 0 590 239 hct 100 V=
w 81
a 0 up 0:33 0 0 0 hln 100 V=
s 720 240 650 240 80
a 0 up 33 0 685 239 hct 100 V=
s 720 260 720 240 82
w 85
a 0 up 0:33 0 0 0 hln 100 V=
s 280 250 280 300 84
s 280 250 340 250 86
a 0 up 33 0 310 249 hct 100 V=
w 126
a 0 up 0:33 0 0 0 hln 100 V=
s 500 430 560 430 99
s 500 440 500 430 104
s 430 430 500 430 70
s 280 430 430 430 66
a 0 up 33 0 355 429 hct 100 V=
s 430 340 430 430 64
s 280 340 280 430 68
s 720 430 720 300 58
s 560 430 600 430 95
s 560 410 560 430 72
s 600 430 720 430 144
s 600 400 600 430 93
w 147
a 0 up 0:33 0 0 0 hln 100 V=
s 560 370 560 360 129
s 560 360 600 360 88
a 0 up 33 0 580 359 hct 100 V=
s 600 360 600 370 90
s 560 270 560 280 149
s 560 280 560 360 164
a 0 up 33 0 562 290 hlt 100 V=
@junction
j 540 110
+ p 5 -
+ w 22
j 610 140
+ s 17
+ w 22
j 430 300
+ p 8 2
+ w 26
j 540 260
+ p 14 B
+ w 26
j 430 210
+ p 6 1
+ w 26
j 430 260
+ w 26
+ w 26
j 370 250
+ p 12 2
+ w 26
j 430 250
+ w 26
+ w 26
j 500 110
+ p 5 +
+ w 45
j 560 170
+ p 11 2
+ w 45
j 430 170
+ p 6 2
+ w 45
j 430 160
+ w 45
+ w 45
j 560 210
+ p 11 1
+ w 55
j 560 240
+ p 14 C
+ w 55
j 620 240
+ p 9 1
+ w 55
j 650 240
+ p 9 2
+ w 81
j 720 240
+ p 19 pin1
+ w 81
j 720 260
+ p 15 2
+ w 81
j 340 250
+ p 12 1
+ w 85
j 280 300
+ p 13 +
+ w 85
j 430 430
+ w 126
+ w 126
j 500 430
+ w 126
+ w 126
j 500 440
+ s 18
+ w 126
j 280 340
+ p 13 -
+ w 126
j 430 340
+ p 8 1
+ w 126
j 720 300
+ p 15 1
+ w 126
j 560 430
+ w 126
+ w 126
j 600 430
+ w 126
+ w 126
j 600 400
+ p 92 1
+ w 126
j 600 370
+ p 92 2
+ w 147
j 560 360
+ w 147
+ w 147
j 560 410
+ p 7 1
+ w 126
j 560 370
+ p 7 2
+ w 147
j 560 280
+ p 14 E
+ w 147
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=B
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
t 2 t 5 750 276 780 290 0 2
Vo
t 3 t 5 750 256 763 270 0 1
+
t 4 t 5 750 296 790 310 0 3
  -
